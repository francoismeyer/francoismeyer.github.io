function CommunitiesOut = CommunityLevelProperties(M,CliqueRep,CutOffDensity)

BaseSizeCutOff = 3;  % the minimum members a clique must have for it to 
                     % serve as a community base

%  Create vector containing the number of members for the largest clique
%  per node
LargestCliqueVec = zeros(length(CliqueRep),1);
for i = 1:length(CliqueRep)
    CurrentCliqueSet = CliqueRep{i};
    for j = 1:length(CurrentCliqueSet)
        if length(CurrentCliqueSet{j}) > LargestCliqueVec(i)
            LargestCliqueVec(i) = length(CurrentCliqueSet{j});
        end
    end
end

[vals, inds] = max(LargestCliqueVec);

LargestCliqueLeft_Size = vals(1);
LargestCliqueLeft_Index = inds(1);

CommunitiesOut= {};


ctr = 0;

while LargestCliqueLeft_Size > BaseSizeCutOff

    %  Set up a vector representation of the community for speed
    CommunityOutVec = sparse(zeros(size(LargestCliqueVec)));
    CommunityOutVecOld = CommunityOutVec;
    CommunityTempVec = CommunityOutVec;
    
    %  Find largest clique in the node's clique set
    NodeCliqueSet = CliqueRep{LargestCliqueLeft_Index};
    MaxCliqueSize = 0;
    for i = 1:length(NodeCliqueSet)
        CurrentCliqueSize = length(NodeCliqueSet{i});
        if CurrentCliqueSize > MaxCliqueSize
            MaxCliqueIndex = i;
            MaxCliqueSize = CurrentCliqueSize;
            TheBiggestClique = CliqueRep{LargestCliqueLeft_Index}{i};
        end
    end
    
    %  Move over to community to start a base
    ctr = ctr + 1;
    CommunitiesOut{ctr} = [];
    CommunitiesOut{ctr} = union(CommunitiesOut{ctr},TheBiggestClique);
    CliqueRep{LargestCliqueLeft_Index}{MaxCliqueIndex} = [];
    
    %  Make vector representation of community for speed
    CommunityOutVec(TheBiggestClique) = 1;
    CommunityOutVecOld = CommunityOutVec;
    
    %  Expand community
    MrBreaker = 0;
    while MrBreaker ~= 1
        CommunitiesOutOld = CommunitiesOut{ctr};
        nNodesOld = length(CommunitiesOutOld);
%         CommunityOutVecOld = CommunityOutVec ;

        
        %  Find the clique that maximizes the edge density quality function
        TopDensity = 0;
        NodeIndex2Add = 0;
        CliqueIndex2Add = 0;
        for I = 1:nNodesOld
            i = CommunitiesOutOld(I);
            CurrentCliqueSet = CliqueRep{i};
            for j = 1:length(CurrentCliqueSet)
                TestClique = CliqueRep{i}{j};
                
                %  Make sure the set has not already been added to a
                %  community [they are made into an empty set in that case]
                if length(TestClique) > 0
                    
                    %  See if these nodes are already part of the community
                    if isempty(MY_setdiff(TestClique,CommunitiesOutOld))
                        CliqueRep{i}{j} = [];
                    else
                    %  If not, see how much it would benefit to add it
%                         CommunitiesOutTemp = union(CommunitiesOutOld,TestClique);
                        
                        CommunityTempVec = MY_setunion_community(CommunityOutVec, TestClique);
                        CommunitiesOutTemp = find(CommunityTempVec);
                        
                        CommunityTempDensity = ClusterDensity(M,CommunitiesOutTemp);
                        %  If this maximizes the density so far, and satisfies the
                        %  cut off, then add it to the set

                        if CommunityTempDensity > CutOffDensity
                            if CommunityTempDensity > TopDensity
                                NodeIndex2Add = i;
                                CliqueIndex2Add = j;
                                TopDensity = CommunityTempDensity;
                            end
                        end
                    end
                    
                end
            end
        end
        
        if NodeIndex2Add > 0
            Clique2Add = CliqueRep{NodeIndex2Add}{CliqueIndex2Add};
            CommunitiesOut{ctr} = union(CommunitiesOutOld,Clique2Add);
            CommunityOutVec = MY_setunion_community(CommunityOutVec, Clique2Add);
            CliqueRep{NodeIndex2Add}{CliqueIndex2Add} = [];
        else
            MrBreaker = 1;
        end
    end
    
    %  Update largest clique vector and locate the next clique to use as a
    %  community base.
    LargestCliqueVec = UpdateLargestCliqueVec(LargestCliqueVec,CliqueRep,CommunitiesOut{ctr});
    [vals, inds] = max(LargestCliqueVec);
    LargestCliqueLeft_Size = vals(1);
    LargestCliqueLeft_Index = inds(1);
        
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  SUBROUTINES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%--------------------------------------------------------------------------
%%  Calculate the connection density of the community
function ClusterDensityOut = ClusterDensity(M,inds)
    X = M(inds,inds);
    ClusterDensityOut = nnz(X)/numel(X);

    
%--------------------------------------------------------------------------
%%  Update Largest Clique Vector
function LargestCliqueVecOut = UpdateLargestCliqueVec(LargestCliqueVec,CliqueRep,NodeSet)

N = length(NodeSet);

LargestCliqueVecOut = LargestCliqueVec;

for i = 1:N
%     keyboard
    I = NodeSet(i);
    CurrentCliqueSet = CliqueRep{I};
    LargestCliqueVecOut(I) = 0;
    for j = 1:length(CurrentCliqueSet)
        if length(CurrentCliqueSet{j}) > LargestCliqueVecOut(I)
            LargestCliqueVecOut(I) = length(CurrentCliqueSet{j});
        end
    end
end

%--------------------------------------------------------------------------
%%  Faster Set Difference
function Z = MY_setdiff(X,Y)
if ~isempty(X)&&~isempty(Y)
  check = false(1, max(max(X), max(Y)));
  check(X) = true;
  check(Y) = false;
  Z = X(check(X));  
else
  Z = X;
end

%--------------------------------------------------------------------------
%%  Faster Set Union
function CommunityTempVec = MY_setunion_community(CommunityOutVec, TestClique)
CommunityTempVec = CommunityOutVec;
CommunityTempVec(TestClique) = 1;


%--------------------------------------------------------------------------
%%  












