function CommunitySetOut = NetworkLevelProperties(CommunitySetIn,M)
%  This function cleans up the output of the FormCommunities function so
%  that every node belongs to at least one community.


CommunitySetInRefined = BinOutliers_ComLinks(CommunitySetIn,M);

CommunitySetOut = FindCover(CommunitySetInRefined,M);

%--------------------------------------------------------------------------
function CommunitiesOut = BinOutliers_ComLinks(CommunitiesIn,M)
%  Make sure there are no nodes w/o a community assignment

UnBinnedNodes = 1:length(M(1,:));

for i = 1:length(CommunitiesIn)
    CommunitiesOut{i} = CommunitiesIn{i};
end

while length(UnBinnedNodes) > 0

    for pp =1:length(CommunitiesIn)
        UnBinnedNodes = setdiff(UnBinnedNodes,CommunitiesIn{pp});
    end

    for i = 1:length(CommunitiesIn)
        CommunitiesIn{i} = CommunitiesOut{i};
    end

    for i = 1:length(UnBinnedNodes)
        TargetNode = UnBinnedNodes(i);
        NodeEdges =  find(M(TargetNode,:));
        MaxOverlap = 0;
        for j = 1:length(CommunitiesIn)
            PercentOverlap = length(intersect(NodeEdges,CommunitiesIn{j}));
            if PercentOverlap > MaxOverlap
                Comm2Bin = j;
                MaxOverlap = PercentOverlap;
            end
        end
        CommunitiesOut{Comm2Bin} = union(CommunitiesOut{Comm2Bin} ,TargetNode);
    end

end

%--------------------------------------------------------------------------
%  Throw away smaller communities subject to the constraint that the
%  resulting communities still provide a cover

function CommunitySetOut = FindCover(CommunitySetIn,M)

SizeVec = zeros(length(CommunitySetIn),1);

UnBinnedNodes = 1:length(M(1,:));
AllNodes = UnBinnedNodes;

for i = 1:length(CommunitySetIn)
    SizeVec(i) = length(CommunitySetIn{i});
end

[ValueVec,IndexVec] = sort(SizeVec,'descend');

ComIndicesOut = [];
CoveredNodes = [];

while length(intersect(CoveredNodes,AllNodes)) ~= length(AllNodes)  % Are there any nodes not in cover
    MaxPercentOverlap = 0;  % track which community can be added that will cover the most new nodes
    
    %  Search for the community that overlaps the least with the
    %  communities present
    for i = 1:length(IndexVec)
        ComIdx = IndexVec(i);
        CurrentPercentOverlap = (length(intersect(UnBinnedNodes,CommunitySetIn{ComIdx}))/(length(CommunitySetIn{ComIdx})));
        if  CurrentPercentOverlap > MaxPercentOverlap
            MaxPercentOverlap = CurrentPercentOverlap;
            ComIdx2Add = ComIdx;
        end
    end
    
    UnBinnedNodes = setdiff(UnBinnedNodes,CommunitySetIn{ComIdx2Add});
    CoveredNodes = union(CoveredNodes,CommunitySetIn{ComIdx2Add});
    ComIndicesOut = union(ComIndicesOut,ComIdx2Add);
end

for i = 1:length(ComIndicesOut)
    CommunitySetOut{i} = CommunitySetIn{ComIndicesOut(i)};
end

