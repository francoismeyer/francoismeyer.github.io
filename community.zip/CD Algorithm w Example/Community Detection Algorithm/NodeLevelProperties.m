function CliqueRep = NodeLevelProperties(M,k)

CliqueRep = {};
for TargetNode = 1:length(M(1,:))
    [ReducedKmeansOutput, CliqueSet, CMatrix] = FindCliques(M,TargetNode,k);
    CliqueRep{TargetNode} = CliqueSet;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%   Main Subroutine
function [ReducedKmeansOutput, CliqueSet, CMatrix] = FindCliques(M,TargetNode,k)
%%  Finds the k largest cliques the target node belongs to
%  M = original adjacency matrix
%  TargetNode = node we are trying to find cliques for
%  SparsifyCutOff = cut off value for similarity between descriptor sets.
%    This is a parameter that controls how we help pop out the clique
%    structure for the TargetNode
%  k = Use the egoblocks that have k*(max egoblock size).  If k is set to
%  an integer greater than one, the algorithm will instead use the k
%  largest egoblocks.

%%  Extract submatrix
%  Pull out the submatrix comprised of the target node, all the nodes it is
%  connected to, and all the edges between those nodes
Node_Row = M(TargetNode,:);  %  the row in the adjacancy matrix for TargetNode
ConnectedNodes = find(Node_Row);  % the nodes the target node is connected to
TargetNodeInCMatrix = find(ConnectedNodes == TargetNode);  % this is the index of the TargetNode in the Cmatrix
CMatrix = M(ConnectedNodes,ConnectedNodes);
% keyboard

%%  Help Reveal the Clique Structure of the TargetNode
CMatrix = SparsifyCMatrix(CMatrix,TargetNodeInCMatrix);


%%  Find the cliques the TargetNode belongs to
[ReducedKmeansOutput, CliqueSet]  = FindCliqueSetForTargetNode(CMatrix,TargetNode,k,ConnectedNodes);
% aout = SpectralClusterByKmeans(CMatrix,TargetNodeInCMatrix,k);



%--------------------------------------------------------------------------
%%  Find the set of cliques for a target node
function [ReducedKmeansOutput, CliqueSet] = FindCliqueSetForTargetNode(CMatrix,TargetNode,k,ConnectedNodes)
%  Inputs:
%       CMatrix = ICM-matrix for the TargetNode
%       k = parameter determining number and or size of cliques to include
%       ConnectedNodes = vector of nodes that share an edge with the
%           TargetNode.

%  Other Functions Used:
%       SpectralClusterByKmeans
%       FormCliqueSets

%  Parameters:
%       MinMembers = the minimum number of members to bother storing the
%           clique as a representation of the node.  This is default
%           hardcoded to 2, the minimum size of a nontrivial clique

MinMembers = 2;

TargetNodeInCMatrix = find(ConnectedNodes == TargetNode); 

[ReducedKmeansOutput, ClusterInfo] = SpectralClusterByKmeans(CMatrix,TargetNodeInCMatrix,k);

CliqueSet = FormCliqueSets(ReducedKmeansOutput, ClusterInfo, TargetNode, ConnectedNodes, MinMembers);

% keyboard

%--------------------------------------------------------------------------
%  Carry out spectral clustering using k-means
function [ReducedKmeansOutput, ClusterInfo] = SpectralClusterByKmeans(SM,TargetNode,k)
%%  Use spectral clustering to find the cliques the target node belongs to
%  Inputs:
%       SM = submatrix of original adjacency matrix comprised of the target
%           node, the nodes it is connected to, and any edges between nodes 
%           in that set
%       TargetNode = Node we are trying to find cliques for
%       k = input parameter for the number of largest cliques we are going
%           use to describe the target node.  If k >= 1, then we interpret
%           this as the integer number of cliques to include in the set.
%           If 0<k<1, then we interpret this as including only cliques with
%           a number of members greater than or equal to k times the number
%           of members in the largest clique

%  Parameters:
%       CutOffDensity = Submatrix density required for being considered an
%                       approximate clique

CutOffDensity = 0.9;  

NN = length(SM(:,1));

A = SM;  
%  Remove the connections belonging to the target node so that we
%  effectively should be dealing with what will reduce to a block diagonal
%  matrix
A(TargetNode,:) = 0;
A(:,TargetNode) = 0;

%  Compute the eigenvectors of A
[V1,D1] = eig(A);
% Ndom = length(V1(1,:));

%  Find the dominant eigenvectors
dd = diag(D1);
alpha = k;
Ndom = length(find(dd > alpha*max(dd)));

%  Take the k dominant eigenvectors
if k > 1
    k = min(k,Ndom-1) + 1;
else
    k = Ndom + 1;
end

%  Scale eigenvectors by eigenvalues
V1 = V1*D1;

L = length(dd);

%  Grab the dominant eigenvectors
X = V1(:,(L:-1:(L-k+1)));  

% ++  Find the clusters  ++
% Create k point by p variable seed matrix

%  find the nodes with the max value in each eigenvector
[vals inds] = max(X);

%  throw away redundancies
inds = union(inds,inds);

%  Construct seed matrix from those nodes
SeedMatrix = X(inds,:);

% keyboard;

%  Carry out k-means clustering.  This produces a vector where the 
KmeansOutput = kmeans(X,[],'start',SeedMatrix,'emptyaction','drop');

%  Set the minimum number of members a clique must have in order to be used
%  to help represent the target node
CutOffMembers = max(floor(alpha*max(dd)),1);

%  
[ReducedKmeansOutput, ClusterInfo]  = Kmeans2Cliques(SM,KmeansOutput,CutOffDensity,CutOffMembers);


% keyboard

%--------------------------------------------------------------------------
%  Find cliques from the k-means output

function [ReducedKmeansOutput, ClusterInfo] = Kmeans2Cliques(SM,KmeansOutput,CutOffDensity,CutOffMembers)
%  Throw away sets of nodes that do not correspond to approximate cliques 
%  in the k-means output

%  Inputs:
%       SM = submatrix containing the target node
%       KmeansOutput = clusters from running spectral k-means clustering
%       CutOffDensity = how dense a cluster has to be in order to be
%           considered an approximate clique
%       CutOffMembers = minimum number of members a set must have in order
%           it to be stored.

N = max(KmeansOutput);
ReducedKmeansOutput = KmeansOutput;

%  If the cluster members do not satisfy the edge density or number of
%  members cut off, then map those members/clusters to the "zeroth" cluster
for i = 1:N
    %  Find the indices corresponding to the ith cluster
    inds = find(KmeansOutput == i);
    if length(inds) >= CutOffMembers
        X = SM(inds,inds);
        ClusterDensity = nnz(X)/numel(X);
        if ClusterDensity < CutOffDensity;
            ReducedKmeansOutput(inds) = 0;
        end
    end
end

%  Now find the cluster numbers that remain and how many members they have
C_Numbers_And_MemberCount = zeros(N,2);
ctr = 1;
for i = 1:N
    %  Find the indices corresponding to the ith cluster
    inds = find(ReducedKmeansOutput == i);
    if ~isempty(inds)
        C_Numbers_And_MemberCount(ctr,:) = [i, length(inds)];
        ctr = ctr + 1;
    end

end

ClusterInfo = C_Numbers_And_MemberCount(1:(ctr-1),:);



%--------------------------------------------------------------------------
%  Form clique sets from [ReducedKmeansOutput, ClusterInfo] output from the
%  SpectralClusterByKmeans subroutine

function CliqueSet = FormCliqueSets(ReducedKmeansOutput, ClusterInfo, TargetNode, ConnectedNodes, MinMembers)

C_vec = ClusterInfo(:,1);  % the remaining clusters

CliqueSet = {};
kk = 1;
for i = 1:length(C_vec)
    CliqueNodesLocal = find(ReducedKmeansOutput == C_vec(i));
    CliqueNodes = ConnectedNodes(CliqueNodesLocal);
    Clique2Add = union(TargetNode,CliqueNodes);
    if length(Clique2Add) >= MinMembers
        CliqueSet{kk} = Clique2Add;
        kk = kk+1;
    end
end

% keyboard






