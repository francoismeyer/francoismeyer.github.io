function [PrecisionVec,RecallVec,Fvec] = PrecisionAndRecallPerGroup(CommunitiesIn,GoldStandard)
%  This function returns the precision, recall, and F-score for each
%  element of CommunitiesIn

PrecisionVec = zeros(length(CommunitiesIn),1);
RecallVec = PrecisionVec;
Fvec = PrecisionVec;

for i = 1:length(CommunitiesIn)
    cvec = CommunitiesIn{i};
    for j = 1:length(GoldStandard(:,1))
        GoldComVec = GoldStandard(j,:);
        GoldCom = union(GoldComVec,GoldComVec);
        GoldCom = setdiff(GoldCom,0);
        gvec = GoldCom;
        %  Note: 0 appears in gvec but is not an index
        NumIntersect = length(intersect(gvec,cvec));
        %  If statement needed for the one node that has full length 
        CurrentRecall = NumIntersect;
        CurrentRecall = CurrentRecall/(length(gvec));
        SetSize = length(find(cvec));
        CurrentPrecision = NumIntersect/SetSize;
        if CurrentPrecision > PrecisionVec(i)
            PrecisionVec(i) = CurrentPrecision;
            RecallVec(i) = CurrentRecall;
            Fvec(i) = 2*(CurrentRecall*CurrentPrecision)/(CurrentRecall+CurrentPrecision);
        end
    end
    
end


