function SM = SparsifyCMatrix(M,TargetNode)
%  This function sparsifies the C-matrix by only keeping the edges
%  between each node and the members of its largest clique.  The matrix is
%  then further sparsified/symmeterized by removing any edges that become 
%  directed through this process (this happens when the largest clique one
%  node belongs to involves a member that belongs to a larger but disjoint
%  clique).

%  Although this is just a subroutine for the MakeCliqueSetsForAllNodes.m
%  function, we are keeping it separate because it is useful as a stand 
%  alone function

SM = M;
Imax = 10;  %  Max number of sparsification iterations

for i = 1:Imax
    SMold = SM;
    SM = SparsifyCMatrixMain(SMold,TargetNode);
    if sum(sum(abs(SM-SMold))) == 0
        break
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  Subroutines
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%--------------------------------------------------------------------------
%  Main function for sparsifying matrix

function SM = SparsifyCMatrixMain(M,TargetNode)

%  Input
%  M = the submatrix corresponding to the TargetNode's C-Matrix
%  TargetNode = the TargetNode's position in its C-Matrix
%  CutOff = Cut off value for descriptor set similarity based connections

%  Returns a sparsified matrix  
%   This algorithm sparsifies an adjacency matrix based on the similarity
%   between descriptor sets for the nodes in the network.

N = length(M(:,1));

%  Make Clique Adjacancy Matrix
%  Here we determine the cliques of each node and throw away the node
%  connections that do not belong to those cliques.  The resulting 
%  adjacancy matrix, CM, then has the cliques for node i stored in row i

CM = M;  % initialize clique matrix

for SubTargetNode = 1:N
    %  Sparsify the matrix M with respect to the TargetNode's connections
    if SubTargetNode ~= TargetNode
        [ConnectedNodes, ConnectionStrengths] = FindLargestCliqueConnections(M,SubTargetNode);
        CM(SubTargetNode,ConnectedNodes) = ConnectionStrengths;
    end
end

SM = CM.*CM';  % initialize similarity matrix
SM(TargetNode,:) = CM(TargetNode,:);
SM(:,TargetNode) = CM(:,TargetNode);

%--------------------------------------------------------------------------
%  Finding connections that belong to the largest cliques

function [ConnectedNodes, ConnectionStrengths] = FindLargestCliqueConnections(M,TargetNode)
%  Uses the dominant eigenvector from the C-Matrix for a target node to
%  find the largest cliques that node belongs to.  It does this by taking
%  all nodes with values above half of the max value in this eigenvector as
%  being members of the largest cliques

%  Can be modified to find the weighted strength of connections between the  
%  target node and its neighbors

Node_Row = M(TargetNode,:);  %  the row in the adjacancy matrix for TargetNode

ConnectedNodes = find(Node_Row);  % the nodes the target node is connected to

N = length(ConnectedNodes);

TargetNodeInSubM = find(ConnectedNodes == TargetNode);

%  Use power method on scaled Cmatrix
if length(ConnectedNodes) > 0

    %  Make sub-matrix of M only including the rows/columns connected to 
    %  the TargetNode
    subM = M(ConnectedNodes,ConnectedNodes);
    
    subM(TargetNodeInSubM,:) = 1/N;
    subM(:,TargetNodeInSubM) = 1/N;


    v = ones(size(subM(:,1)));
    %  Take a power of the sub matrix to speed up power method
    subM = subM^5;
    subM = sparse(subM);
    
    %  Using power method to get dominant eigenvector
    for kk = 1:4
       vnext = subM*v;
       dd = 1.0/sum(vnext);
       v = vnext*dd;
    end

    
    
    v(TargetNodeInSubM) = max(v);
    v = v/sum(v);

    %  Determine if connection should be pruned
    ConnectionStrengths = 1.0*(v >= 0.5*(max(v)) );  % using max as cut off

%  Other things tried for determining clique members
%     ConnectionStrengths = 1.0*(v >= (max(v)-std(v)) );  %  using standard deviation for cut off
%     ConnectionStrengths = 1.0*(v >= 0.5*(max(v)+mean(v)) );  %  using mean as cut off  [std works better]
else
    ConnectionStrengths = [];
end   



