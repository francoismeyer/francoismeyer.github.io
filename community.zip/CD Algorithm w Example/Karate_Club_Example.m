close all
clear
clc

%%  Descripton
%  This example will construct the adjacency matrix for the Zachary karate
%  club network and run our community detection algorithm on it.



%%  Link required folders 
CurrentFolder = pwd;
addpath(horzcat(CurrentFolder,'\Karate Club Matrix and Data'))
addpath(horzcat(CurrentFolder,'\Community Detection Algorithm'))

%%  Set up Zachary karate club adjacency matrix and gold standard groupings

% adjacency matrix
% Note:  This function will automatically add in the self connections
M = MakeKarateClubMatrix();

% gold standard groupings
G1 = [25,26,32,28,24,29,9,34,33,30,27,19,31,10,16,21,15,23];
G2 = [17,6,7,12,11,5,1,20,22,3,2,8,18,13,4,14];

% make matrix with gold standard groupings for evaluation purposes
GoldStandardClusterMatrix = zeros(2,max(length(G1),length(G2)));
GoldStandardClusterMatrix(1,1:length(G1)) = G1;
GoldStandardClusterMatrix(2,1:length(G2)) = G2;

                             
%%  Set up community detection algorithm inputs

kk = 0.1;   %  This parameter controls the sizes of the edge descriptor 
            %  sets that are used to represent the potential community 
            %  membership of each node.  Specifically, if X is the number 
            %  of nodes involved in the largest egoblock a node 
            %  belongs to then we will only include egoblocks 
            %  that involve kk*X nodes or more.  Alternativel, if kk >= 1,
            %  this will cause the program to look for that many egoblocks
            %  (i.e. you can specify if you only want to consider the kk
            %  largest egoblocks instead of all of them falling above a
            %  threshold.

%  Estimate community density.  As a default, we use a density equal to 3/4
%  of the average egonet edge density.
AveLocalDensity = 0;
for i = 1:length(M(:,1))
    c1 = find(M(i,:));
    LocalEgonet = M(c1,c1);
    LocalDensity = nnz(LocalEgonet)/prod(size(LocalEgonet));
    AveLocalDensity = AveLocalDensity + LocalDensity;
end
AveLocalDensity = AveLocalDensity/length(M(:,1));
CutOffDensity = 0.75*AveLocalDensity;

%%  Run community detection algorithm

%  Create edge descriptor sets
CliqueRep = NodeLevelProperties(M,kk);

%  Agglomerate edge descriptor sets
CommunitySetOut = CommunityLevelProperties(M,CliqueRep,CutOffDensity);

%  Enforce network constraints
CommunitiesOut_CleanedUp = NetworkLevelProperties(CommunitySetOut,M);

%%  Display the gold standard communities and the detected communities
disp('Gold Standard Communities')
G1
G2

disp('Detected Communities')
Community_1 = CommunitiesOut_CleanedUp{1}'
Community_2 = CommunitiesOut_CleanedUp{2}'
Community_3 = CommunitiesOut_CleanedUp{3}'

disp('Precision, Recall, and F-scores')
[PrecisionVec,RecallVec,Fvec] = PrecisionAndRecallPerGroup(CommunitiesOut_CleanedUp,GoldStandardClusterMatrix)


