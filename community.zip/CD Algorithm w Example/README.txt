______________________________________________________________________________

 Copyright (C) 2014 Michael Brutz <brutz@colorado.edu>

 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are met:

   a. Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.

   b. Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.

   c. Neither the name of the copyright holders nor the names of any
      contributors to this software may be used to endorse or promote products
      derived from this software without specific prior written permission.


 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ON AN
 "AS IS" BASIS. THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO
 REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.  BY WAY OF EXAMPLE, BUT
 NOT LIMITATION, THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO AND
 DISCLAIMS ANY REPRESENTATION OR WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 ANY PARTICULAR PURPOSE OR THAT THE USE OF THIS SOFTWARE WILL NOT INFRINGE
 ANY THIRD PARTY RIGHTS.

 THE COPYRIGHT HOLDERS AND CONTRIBUTORS SHALL NOT BE LIABLE TO LICENSEE OR
 ANY OTHER USERS OF THIS SOFTWARE FOR ANY INCIDENTAL, SPECIAL, OR
 CONSEQUENTIAL DAMAGES OR LOSS AS A RESULT OF MODIFYING, DISTRIBUTING, OR
 OTHERWISE USING THIS SOFTWARE, OR ANY DERIVATIVE THEREOF, EVEN IF ADVISED
 OF THE POSSIBILITY THEREOF.
______________________________________________________________________________



This code provides an example implimentation of the community detection 
algorithm presented in "A Flexible Multiscale Approach to Overlapping 
Community Detection", M. Brutz and F.G. Meyer, Social Network Analysis and 
Mining.


______________________________________________________________________________
Contents:

AdjustableParamaters.txt:  This document contains a list of the potentially
adjustable harded parameters.



Karate_Club_Example.m:  This MATLAB script runs the algorithm on the karate 
club network.

Sparsification_Accuracy_Test.m:  This MATLAB script performs the 
sparsification tests presented in the manuscript.



Community Detection Algorithm Folder:  This folder contains the three modules
used in the community detection algorithm to enforce properties at the node, 
community, and network levels.  Additionally, this folder contains a separate
function for the sparsification algorithm to be used as a stand alone code.

Karate Club Matrix and Data Folder:  This folder contains the data and MATLAB
function to create the karate club adjacency matrix.  Note: The function will 
automatically add in self connections to all the nodes for the sake of 
efficiency (otherwise, the sparsification process will have to do this every 
time it is called).

Sparsification Programs Folder:  This folder contains the programs required 
for the sparsification tests.




Please report any bugs or send feedback to:

Michael Brutz
brutz@colorado.edu