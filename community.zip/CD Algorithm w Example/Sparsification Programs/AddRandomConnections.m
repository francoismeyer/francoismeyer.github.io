function Mout = AddRandomConnections(M,p)
%%  Makes a random matrix with a clique in it
%  k = number of members in clique
%  N = number of nodes in subnetwork
%  p = probability of connection between network members

N = length(M(1,:));

A = rand(N);
q = 1-sqrt(1-p);  %  so end prob of connection is 1-(1-q)^2 = p
A = A<q;
A = A + A' + eye(N);
A = 1.0*(A>0);

Mout = M + A;
Mout = Mout > 0;
Mout = 1.0*Mout;




