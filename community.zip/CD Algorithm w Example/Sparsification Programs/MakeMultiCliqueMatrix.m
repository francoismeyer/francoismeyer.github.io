function M = MakeMultiCliqueMatrix(G_vec,L_vec,Scaled)
%%  Makes a matrix and gold standard clustering
%  This matrix keeps the expected number of links per node fixed.
%  G_vec = vector where each entry, i, is the number of groups with
%          L_vec(i) members
%  L_vec = vector with number of nodes per group
%  Pout = probability to be connected to random node in the network.
%  NOTE:  The inputs need to be column vectors


N = G_vec'*L_vec;

M = zeros(N+1);

IstartOld = 1;
% Gidx = 0;

%%  Original adjacency matrix
if Scaled == 0
    M(:,1) = 1;
    M(1,:) = 1;

%%  Connections to target node are scaled by number of connections
elseif Scaled == 1
    M(:,1) = 1/N;
    M(1,:) = 1/N;

%     M(:,1) = 1/2;
%     M(1,:) = 1/2;

%%  Make target node disconnected
elseif Scaled == -1
    M(:,1) = 0;
    M(1,:) = 0;    
    M(1,1) = 1;
end

%%  Connections to target node are scaled by number of cliques
%  This scaling reduces the dimension of the range by 1
% M(:,1) = 1/sum(G_vec);
% M(1,:) = 1/sum(G_vec);


for i = 1:length(G_vec)
    
    G = G_vec(i);
    L = L_vec(i);

    for g = 1:G
       clear Msub
       Msub = ones(L);
       Istart = IstartOld + L*(g-1)+1;
       Iend = IstartOld + L*g;
       clear Ivec
       Ivec = Istart:Iend;
       M(Ivec,Ivec) = Msub(:,:);
%        Gidx = Gidx + 1;
    end
    
    IstartOld = Iend;
    
end

% Make symmetric
% UpM = triu(M);
% % M = UpM + UpM' - eye(N);
% M = UpM + UpM' + eye(N);
% M = M>0;

