%  This script is for numerically testing the sparsification accuracy

clc
clear


%%  Link required folders 
CurrentFolder = pwd;
addpath(horzcat(CurrentFolder,'\Sparsification Programs'))

%%  Set sparsification parameter
kk = 0.1;   % parameter controlling number of eigenvectors to use.  The 
            % default is to use all with eigenvalues >= 0.1*(max
            % eigenvalue).  Note, if kk is set to an integer >= 1, then 
            % the the kk largest eigenvectors will be used.

%%  Set up tests

NumTrials = 1;  % number of trials to run per data point

%  Clique Graph Parameters
Scaled = 0;

G_vec = [10]';  % number of groups
L_vec = [10]';  % number of members


NumberOfNodes = (sum(L_vec.*G_vec));

Pmin = 0;
Pmax = 3*min(L_vec)/(sum(L_vec.*G_vec));  

NumSteps = 20;

Pstep = (Pmax-Pmin)/NumSteps;

p_vec = Pmin:Pstep:Pmax;

M = MakeMultiCliqueMatrix(G_vec,L_vec,Scaled);
TargetNode = 1;




for P2Use = 1:length(p_vec)
    p = p_vec(P2Use);
    
    ConnectionRemovalAccuracyAve = 0;
    for TrialNum = 1:NumTrials
        clear KMClusters
        Mout = AddRandomConnections(M,p);
        [KMClusters, CliqueSet, Mreduced] = FindCliques(Mout,TargetNode,kk);
        ConnectionRemovalAccuracyAve = ConnectionRemovalAccuracyAve + nnz(Mreduced-M)/nnz(Mout-M);
    end
    ConnectionRemovalAccuracy(P2Use) = 1 - ConnectionRemovalAccuracyAve/NumTrials;
end


figure(1)
spy(Mout)
title('Before Sparsification')

figure(2)
spy(Mreduced)
title('After Sparsification')

RatioOfInlinks2Outlinks = p_vec*(min(L_vec)/(sum(L_vec.*G_vec)))^(-1);

figure(21)
plot(RatioOfInlinks2Outlinks,ConnectionRemovalAccuracy,'-x')
title('Connection Removal Accuracy')
xlabel('Ratio of Outlinks to Inlinks')
ylabel('Accuracy')




