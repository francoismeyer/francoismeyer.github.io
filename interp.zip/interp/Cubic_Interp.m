function [Yproj] = Cubic_Interp(X,Y,Xproj)
% Code my N.Monnig 3/20/2013 for interpolation of data using cubic RBF.
% CODE IS PROVIDED "AS-IS".  AUTHOR ASSUMES NO LIABILITY FOR ERRORS OR
% OMISSIONS, OR MIS-USE OF CODE.
%
% Contact:
% Nathan Monnig
% Graduate Student, Applied Mathematics Department
% University of Colorado Boulder
% nathan.monnig@colorado.edu
%
% INPUTS
% X = data locations in R^d (N x d array)
% Y = function values in R^D corresponding to points X in domain (N x D array)
%           N = # of data points
% Xproj = new points in R^d to interpolate at
%
% OUTPUTS
% Yproj = interpolated function values for new domain points Xproj
%
% BRIEF EXPLANATION OF ALGORITHM
% Y=f(X) is approximated by a cubic RBF with constant and linear polynomial
% terms.  

% begin code:
N=size(X,1);
d=size(X,2);
D=size(Y,2);
% find order of magnitude for domain (provides stability of constant term)
magX=max(max(abs(X)));
% set up system of equations for cubic RBF + constant & linear terms
A=[squareform(pdist(X).^3),magX*ones(N,1),X;...
  [magX*ones(1,N);X'],zeros(d+1,d+1)];
b=[Y;zeros(d+1,D)];
% solve system
alpha=A\b;
% interpolate at new locations
Yproj=[pdist2(Xproj,X).^3,magX*ones(size(Xproj,1),1),Xproj]*alpha; 


