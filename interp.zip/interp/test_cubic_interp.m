clc; clear all; close all;
% Code by N.Monnig 5/25/2013 for testing of Cubic_Interp.m interpolation algorithm.

%
D=3;
d=2;
N=200;
% scatter some nodes
X=halton(N,d);
% interpolate to a mesh
[grid1,grid2]=meshgrid(0:0.05:1);
Xproj=[grid1(:),grid2(:)];
% build some silly function
Y=[cos(2*pi*X(:,1))-X(:,2),2*X(:,1).^2+5,sin(pi*X(:,2)).^2-cos(X(:,1))];
% interpolate!
[Yproj] = Cubic_Interp(X,Y,Xproj);

% Let's take a look-sie-poo
subplot(2,3,1)
scatter3(Xproj(:,1),Xproj(:,2),Yproj(:,1),10,Yproj(:,1))
title('F_1')
subplot(2,3,4)
surf(grid1,grid2,reshape(Yproj(:,1)-(cos(2*pi*Xproj(:,1))-Xproj(:,2)),size(grid1)))
title('Interpolation Error')

subplot(2,3,2)
scatter3(Xproj(:,1),Xproj(:,2),Yproj(:,2),10,Yproj(:,2))
title('F_2')
subplot(2,3,5)
surf(grid1,grid2,reshape(Yproj(:,2)-(2*Xproj(:,1).^2+5),size(grid1)))
title('Interpolation Error')

subplot(2,3,3)
scatter3(Xproj(:,1),Xproj(:,2),Yproj(:,3),10,Yproj(:,3))
title('F_3')
subplot(2,3,6)
surf(grid1,grid2,reshape(Yproj(:,3)-(sin(pi*Xproj(:,2)).^2-cos(Xproj(:,1))),size(grid1)))
title('Interpolation Error')